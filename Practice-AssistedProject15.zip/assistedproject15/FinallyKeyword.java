package assistedproject15;

public class FinallyKeyword {
	public static void main(String[] args)
    {
        int a=20,b=0,result=0;
        try
        {
            result = a / b;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\nThe result is : " + result);
        }
    }

}
