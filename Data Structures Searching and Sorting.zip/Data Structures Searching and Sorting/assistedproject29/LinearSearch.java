package assistedproject29;

import java.util.Scanner;

public class LinearSearch{
    public static void main(String[] args) {
        int[] ar= {1,5,4,3,2,6,7};
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element to be searched");
        int key = sc.nextInt();
        boolean output = false;
        for(int i=0;i<ar.length;i++){
        	if(key == ar[i]){
        	   output=true;
        	}
        }
        if(output==true){
        	System.out.println("Value found");
        }
        else {
        	System.out.println("Value not found");
        }
    }
}

