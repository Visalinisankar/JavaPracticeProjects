package pack1;

public class PubAccessModifier {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 
}
