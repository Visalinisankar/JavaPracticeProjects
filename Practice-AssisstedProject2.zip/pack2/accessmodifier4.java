package pack2;

import pack1.*;
public class accessmodifier4 {
public static void main(String[] args) {
		PubAccessModifier obj = new PubAccessModifier(); 
        obj.display();  
	}
}
