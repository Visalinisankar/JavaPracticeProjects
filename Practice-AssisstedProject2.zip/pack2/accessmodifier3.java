package pack2;

import pack1.*;

public class accessmodifier3 extends ProAccessModifier {
	public static void main(String[] args) {
		accessmodifier3 obj = new accessmodifier3 ();   
	       obj.display();  
	}
}
