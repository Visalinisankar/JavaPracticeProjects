package assistedproject14;

public class TryCatch {
	public static void main(String args[]) 
    {
        int[] ar = new int[2];
        for(int i=0;i<4;i++) {
        try 
        {
            ar[i] = 3;
            System.out.println("\nValue Stored in array is "+ar[0]);
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("\nIndex is out of boundary"); 
        }
        finally 
        {
            System.out.println("The size of the array is " + ar.length);
        }
        }
    }
}
