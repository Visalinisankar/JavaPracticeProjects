package assistedproject15;

public class ThrowsKeyword {
    void Division() throws ArithmeticException
    {
        int a=20,b=0,result;
        result = a / b;
        System.out.print("The result is : " + result);
       
    }
     public static void main(String[] args)
    {
    	 ThrowsKeyword T = new ThrowsKeyword();
         try
        {
            T.Division();
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error : " + Ex.getMessage());
        }
        System.out.print("\nEnd of program.");
    }

}
