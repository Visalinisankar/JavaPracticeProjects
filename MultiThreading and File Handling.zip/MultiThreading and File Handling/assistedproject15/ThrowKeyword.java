package assistedproject15;

public class ThrowKeyword {
	public static void main(String[] args)
    {

        int a=20,result;
        for(int b=0;b<2;b++) {
        try
        {
            if(b==0)        
                throw(new ArithmeticException("Can't divide by zero."));
            else
            {
                result = a / b;
                System.out.print("\nThe result is : " + result);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error : " + Ex.getMessage());
        }

        System.out.print("\nEnd of program\n");
        }
    }
}
