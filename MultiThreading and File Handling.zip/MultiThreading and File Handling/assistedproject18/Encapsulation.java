package assistedproject18;

class Account {  
	private long accountnumber;  
	private String name,email;  
	private float amount;  
	public long getAccountNumber() {  
		return accountnumber;  
		}  
	public void setAccountNumber(long accountnumber) {  
		this.accountnumber = accountnumber;
		}  
	public String getName() {  
		return name;  
	}  
	public void setName(String name) {  
		this.name = name;  
	}  
	public String getEmail() {  
		return email;  
	}  
	public void setEmail(String email) {  
		this.email = email;  
	}  
	public float getAmount() {  
		return amount;  
	}  
	public void setAmount(float amount) {  
		this.amount = amount;  
	}  
}
public class Encapsulation {  
	public static void main(String[] args) {  
		Account a=new Account();  
		a.setAccountNumber(66358412);  
		a.setName("Alexa Agarwal");  
		a.setEmail("alexaagarwal@hotmail.com");  
		a.setAmount(500000f);  
		System.out.println("Account Number: "+a.getAccountNumber()+"\nAccount Holder Name: "+a.getName()+"\nE-mail Id: "+a.getEmail()+"\nAmount: "+a.getAmount());  
	}  
}