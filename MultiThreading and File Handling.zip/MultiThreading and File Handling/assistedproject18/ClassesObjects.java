package assistedproject18;

public class ClassesObjects{  
    String brand; 
    String flavour; 
    int Quantity; 
    String color; 
    public ClassesObjects(String brand, String flavour, int quantity, String color) 
    { 
        this.brand = brand; 
        this.flavour = flavour; 
        this.Quantity = quantity; 
        this.color = color; 
    } 
    public String getBrand() 
    { 
        return brand; 
    } 
    public String getFlavour() 
    { 
        return flavour; 
    } 
    public int getQuantity() 
    { 
        return Quantity; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Icecream Brand: "+ this.getBrand()+ ".\nI need " + this.getFlavour()+" Flavour,and Quantity of " + this.getQuantity()+ ", and of "+ this.getColor() + "Color."); 
    } 
    public static void main(String[] args) 
    { 
    	ClassesObjects scott = new ClassesObjects("Arun Iceream","Red Velvet", 4, "pinkish red "); 
        System.out.println(scott.toString()); 
    } 
}
