package assistedproject18;

public class Polymorphism {
	 public int calculation(int x, int y) 
	 { 
	        return (x * y); 
	 } 
	 public int calculation(int x, int y, int z) 
	 { 
	        return (x + y + z); 
	 } 
	 public double calculation(double x, double y) 
	 { 
	        return (x + y); 
	 } 
	 public static void main(String args[]) 
	 { 
	        Polymorphism s = new Polymorphism(); 
	        System.out.println("Product of Two numbers 10 and 20 is "+s.calculation(10, 20)); 
	        System.out.println("Sum of Three numbers 10,20,30 is "+s.calculation(10, 20, 30)); 
	        System.out.println("Subtraction of Decimal numbers 20.5 and 10.5 is "+s.calculation(20.5, 10.5)); 
	 } 

}
