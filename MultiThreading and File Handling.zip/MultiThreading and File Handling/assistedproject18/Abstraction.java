package assistedproject18;

abstract class Shape  
{ 
    String color; 
    abstract double area(); 
    public abstract String toString(); 
    public Shape(String color) 
    { 
        System.out.println("Shape Constructor called"); 
        this.color = color; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
} 
class Square extends Shape 
{ 
    double side; 
    public Square(String color,double side) 
    { 
        super(color); 
        System.out.println("Square Constructor called"); 
        this.side = side; 
    }
    @Override
    double area() 
    { 
        return Math.PI * Math.pow(side, 2); 
    } 
    @Override
    public String toString() 
    { 
        return "Square color is "+super.color+" and area is : "+area(); 
    } 
} 
class Rectangle extends Shape
{ 
    double length; 
    double width; 
    public Rectangle(String color,double length,double width) 
    { 
        super(color); 
        System.out.println("Rectangle constructor called"); 
        this.length = length; 
        this.width = width; 
    } 
    @Override
    double area() 
    { 
        return length*width; 
    } 
    @Override
    public String toString() 
    { 
        return "Rectangle color is "+super.color+ "and area is : "+area(); 
    } 
} 
public class Abstraction  
{ 
    public static void main(String[] args) 
    { 
        Shape s1 = new Square("Red", 2.5); 
        Shape s2 = new Rectangle("Yellow", 2, 4);
        System.out.println(s1.toString()); 
        System.out.println(s2.toString()); 
    } 
}
