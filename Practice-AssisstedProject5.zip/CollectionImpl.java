package assisstedproject5;

import java.util.*;

public class CollectionImpl {

	public static void main(String[] args) {
		//arraylist
		System.out.println("ArrayList");
		ArrayList<String> city=new ArrayList<String>();   
		city.add("Bangalore");//
		city.add("Chennai");
		city.add("Mumbai");
		System.out.println(city);  
				
		//vector
		System.out.println("\n");
		System.out.println("Vector");
		Vector<Integer> vec = new Vector();
		vec.addElement(5); 
		vec.addElement(10); 
		vec.addElement(15);
		System.out.println(vec);
						
		//linkedlist
		System.out.println("\n");
		System.out.println("LinkedList");
		LinkedList<String> name=new LinkedList<String>();  
		name.add("Alexa");  
		name.add("Jack");  	      
		Iterator<String> i=name.iterator();  
		while(i.hasNext()){  
		System.out.println(i.next());  
			       
		// hashset
		System.out.println("\n");
		System.out.println("HashSet");
		HashSet<Integer> set1=new HashSet<Integer>();  
		set1.add(101);  
		set1.add(103);  
		set1.add(102);
		set1.add(104);
		System.out.println(set1);
			       
		//linkedhashset
		System.out.println("\n");
		System.out.println("LinkedHashSet");
		LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
		set2.add(11);  
		set2.add(13);  
		set2.add(12);
		set2.add(14);	       
		System.out.println(set2);
		} 

	}

}
