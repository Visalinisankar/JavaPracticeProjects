package Login;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class LoginTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Visalini S\\Downloads\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://login.yahoo.com/?specId=yidregsimplified&done=https%3A%2F%2Fwww.yahoo.com&intl=in&prompt=login");
		
		System.out.println("Title of the page is :" + driver.getTitle());
		WebElement fn = null ;
		driver.findElement(By.name("username")).sendKeys("visalinisankar17@yahoo.com");
		TakesScreenshot ts = (TakesScreenshot)driver;
		File fn1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(fn1, new File("L-user.png"));
		
		WebElement sub = null ;
		driver.findElement(By.name("signin")).click();
		TakesScreenshot ts2 = (TakesScreenshot)driver;
		File sub1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(sub1, new File("L-signin.png"));
		
		WebElement password = null ;
		driver.findElement(By.name("password")).sendKeys("visu1234");
		TakesScreenshot ts3 = (TakesScreenshot)driver;
		File password1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(password1, new File("L-password.png"));
		
		WebElement sub2 = null ;
		driver.findElement(By.name("verifyPassword")).click();
		TakesScreenshot ts4 = (TakesScreenshot)driver;
		File sub3 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(sub3, new File("L-verify.png"));
		
	}

}
