package Register;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class RegisterTest {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Visalini S\\Downloads\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://login.yahoo.com/account/create?specId=yidregsimplified&done=https%3A%2F%2Fwww.yahoo.com");
		
		System.out.println("Title of the page is :" + driver.getTitle());
		WebElement fn = null ;
		driver.findElement(By.name("firstName")).sendKeys("visalini");
		TakesScreenshot ts = (TakesScreenshot)driver;
		File fn1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(fn1, new File("fname.png"));
		
		WebElement ln = null ;
		driver.findElement(By.name("lastName")).sendKeys("sankar");
		TakesScreenshot ts1 = (TakesScreenshot)driver;
		File ln1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(ln1, new File("lname.png"));
		
		WebElement email = null ;
		driver.findElement(By.name("userId")).sendKeys("visalinisankar17");
		TakesScreenshot ts2 = (TakesScreenshot)driver;
		File email1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(email1, new File("email.png"));
		
		WebElement password = null ;
		driver.findElement(By.name("password")).sendKeys("visu1234");
		TakesScreenshot ts3 = (TakesScreenshot)driver;
		File password1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(password1, new File("password.png"));
		
		WebElement by = null ;
		driver.findElement(By.name("birthYear")).sendKeys("2001");
		TakesScreenshot ts4 = (TakesScreenshot)driver;
		File by1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(by1, new File("by.png"));
		
		WebElement sub = null ;
		driver.findElement(By.name("signup")).click();
		TakesScreenshot ts5 = (TakesScreenshot)driver;
		File sub1 = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(sub1, new File("signup.png"));	
	}
}
