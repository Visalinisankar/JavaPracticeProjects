package assistedproject23;

public class Matrix
{
	public static void main(String[] args) {
       	int r1 = 3, c1 = 2;
        int r2 = 2, c2 = 3;
        int[][] fm = { {2, -3}, {6, 5}, {7, 4} };
        int[][] sm = { {1, 0, 8}, {4, 9, 0} };
        int[][] p = Matrices(fm, sm, r1, c1, c2);
        displayProduct(p);
    }
	public static int[][] Matrices(int[][] fm, int[][] sm, int r1, int c1, int c2) {
        int[][] p = new int[r1][c2];
        for(int i = 0; i < r1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                	p[i][j] += fm[i][k] * sm[k][j];
                }
            }
       	 }
        return p;
    }
	public static void displayProduct(int[][] product) {
        System.out.println("Product of two matrices is: ");
        for(int[] row : product) {
            for (int column : row) {
                System.out.print(column + "    ");
            }
            System.out.println();
        }
    }
}