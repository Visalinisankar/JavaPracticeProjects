package assistedproject28;

import java.util.*;

public class QueueAP {
	public static void main(String[] args) {
		Queue<String> MobileBrandQueue = new LinkedList<>();
		MobileBrandQueue.add("Oppo");
		MobileBrandQueue.add("Redmi");
		MobileBrandQueue.add("Vivo");
		MobileBrandQueue.add("Samsung");
		MobileBrandQueue.add("Apple");
	    System.out.println("Queue is : " + MobileBrandQueue);
	    System.out.println("Size of Queue : " + MobileBrandQueue.size());
   		System.out.println("Head of Queue : " + MobileBrandQueue.peek());
   		MobileBrandQueue.remove();
	    System.out.println("After removing Head of Queue : " + MobileBrandQueue);
	    System.out.println("Size of Queue : " + MobileBrandQueue.size());
	}
}

