package assistedproject20;

class RotateArray { 
	public void rotate(int[] a, int b) {
    	if(b > a.length) 
       		b=b%a.length;
 		int[] result = new int[a.length];
 		for(int i=0; i < b; i++){
        	result[i] = a[a.length-b+i];
 		}
 		int j=0;
    	for(int i=b; i<a.length; i++){
        	result[i] = a[j];
        	j++;
    	}
 		System.arraycopy( result, 0, a, 0, a.length );
	}
} 
public class ArrayRotation{
	public static void main(String[] args) {
		RotateArray obj = new RotateArray();
        int arr[] = { 1, 2, 3, 4, 5, 6, 7 }; 
        obj.rotate(arr, 5); 
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");
        }
	}
}
