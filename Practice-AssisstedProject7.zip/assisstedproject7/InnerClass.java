package assisstedproject7;

public class InnerClass {

	private String msg = "Implementation of"; 
	 
	 class Inner{  
	  void display(){
		  System.out.println(msg+" Inner Classes");}  
	 }  
	public static void main(String[] args) {
		InnerClass obj=new InnerClass();
		InnerClass.Inner in=obj.new Inner();  
		in.display();  
	}
}
