package assisstedproject7;

public class InnerClass1 {
	
	private String msg="Inner Class";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println("*"+msg+"*");
			 }  
	     }  
	  Inner l=new Inner();  
	  l.msg();  
	  }  
 
	public static void main(String[] args) {
		InnerClass1  in = new InnerClass1 ();  
		in.display();  
	}
}
