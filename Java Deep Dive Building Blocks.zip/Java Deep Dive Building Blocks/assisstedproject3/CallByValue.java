package assisstedproject3;

public class CallByValue {
	int a=150;
	int operation(int a) {
		a = a*10/100;
		return(a);
	}

	public static void main(String args[]) {
		CallByValue obj = new CallByValue();
		System.out.println("Before operation value of data is "+obj.a);
		obj.operation(100);
		System.out.println("After operation value of data is "+obj.a);
		}
}
