package assistedproject2;

class accessmodifier1 {
	void display() 
    { 
        System.out.println("You are using defalut access specifier"); 
    } 
}
public class AccessModifiers {
	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		accessmodifier1 obj = new accessmodifier1(); 		  
        obj.display(); 
	}
}
