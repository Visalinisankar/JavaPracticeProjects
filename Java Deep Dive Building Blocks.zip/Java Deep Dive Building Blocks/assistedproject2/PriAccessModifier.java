package assistedproject2;

class accessmodifier2{
	private void display() 
    { 
        System.out.println("You are using private access specifier"); 
    } 
} 

public class PriAccessModifier {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		accessmodifier2  obj = new accessmodifier2(); 
        //trying to access private method of another class 
        //obj.display();
	}
}