package assisstedproject4;

class Students{
	int Reg_no;
	String Name;
	String Department;
	
	Students(int a,String b,String c){
		Reg_no=a;
		Name=b;
		Department=c;
	}	
	void display()
	{
		System.out.println(Reg_no+" : "+Name+" - "+Department);
	}
}
public class ParameterizedConstructor {
	public static void main(String[] args) {
		Students s1=new Students(1234,"Alexa","ECE");
		Students s2=new Students(5678,"Jack","IT");
		s1.display();
		s2.display();
		}
}
