package assisstedproject4;

class Student{
	int Reg_no;
	String Name;
	
	void display()
	{
		System.out.println(Reg_no+" - "+Name);
	}
}

public class Constructor {
	public static void main(String[] args) {
		Student s1=new Student();
		Student s2=new Student();
		s1.display();
		s2.display();
		}
}
