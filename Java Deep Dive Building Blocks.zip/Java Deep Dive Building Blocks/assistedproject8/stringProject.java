package assistedproject8;

public class stringProject {

		public static void main(String[] args) {
			
			String sl=new String("Hello World");
			System.out.println(sl.length());
			System.out.println("\n");
			
			//String Comparison
			String s1="Hello";
			String s2="HELLO";
			System.out.println(s1.compareTo(s2));
			System.out.println("\n");

			//IsEmpty
			String s4="";
			String st="Hi";
			System.out.println(s4.isEmpty());
			System.out.println(st.isEmpty());
			System.out.println("\n");

			//replace
			String s6="Heldo";
			String replace=s6.replace('d', 'l');
			System.out.println(replace);
			System.out.println("\n");

			//toLowerCase
			String s5="Hello";
			System.out.println(s5.toLowerCase());
			System.out.println(s5.toUpperCase());
			System.out.println("\n");
			
			//substring
			String sub=new String("Welcome");
			System.out.println(sub.substring(3));
			System.out.println("\n");
			
			//equals
			String x="Java project";
			String y="JaVa ProjecT";
			System.out.println(x.equals(y));
			System.out.println(x.equalsIgnoreCase(y));
			System.out.println("\n");
	 
			//Creating StringBuffer and append method
			StringBuffer s=new StringBuffer("Java Practice");
			s.append("Assisted Project");
			System.out.println(s);
			System.out.println("\n");

			//insert method
			s.insert(12, '-');
			s.insert(29, "-8");
			System.out.println(s);
			System.out.println("\n");

			//replace method
			StringBuffer sb=new StringBuffer("Hello");
			sb.replace(0, 2, "hEl");
			System.out.println(sb);
			System.out.println("\n");

			//delete method
			sb.delete(0, 1);
			System.out.println(sb);
			System.out.println("\n");
			
			//StringBuilder
			StringBuilder sb1=new StringBuilder("A Happy");
			sb1.append(" Weekend");
			System.out.println(sb1);
			System.out.println("\n");
			System.out.println(sb1.delete(0, 2));
			System.out.println("\n");
			System.out.println(sb1.insert(0, "Let's celebrate "));
			System.out.println("\n");
			System.out.println(sb1.reverse());
			System.out.println("\n");
					
			//conversion	
			String str = "Hello"; 
			
	        // conversion from String object to StringBuffer 
	        StringBuffer sbr = new StringBuffer(str); 
	        sbr.reverse(); 
	        System.out.println("String to StringBuffer");
	        System.out.println(sbr); 
	        System.out.println("\n");
	          
	        // conversion from String object to StringBuilder 
	        StringBuilder sbl = new StringBuilder(str); 
	        sbl.append("world"); 
	        System.out.println("String to StringBuilder");
	        System.out.println(sbl);        
	        System.out.println("\n");
		}

}
