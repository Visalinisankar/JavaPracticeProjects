package Login;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RegisterTest {
	String driverPath="C:\\Users\\Visalini S\\Downloads\\chromedriver.exe";
	public WebDriver driver;
  @Test
  public void f() throws IOException, InterruptedException {
  
  driver.manage().window().maximize();
	driver.get("https://accounts.google.com/signup/v2/webcreateaccount?biz=true&cc=IN&continue=http%3A%2F%2Fsupport.google.com%2Fmail%2Fanswer%2F56256%3Fhl%3Den&dsh=S1526758945%3A1665156203296819&flowEntry=SignUp&flowName=GlifWebSignIn&hl=en&ifkv=AQDHYWqED3NRpq4EizsEAdJbn6ws3S0uUoDX7WMdR3A-WJu2Q3lTT-oC8a7YgzqXtXXW4ioi0bKfYg");
	
	driver.findElement(By.id("firstName")).sendKeys("nilasi");
	TakesScreenshot tsc = (TakesScreenshot) driver;	
		File rsc = tsc.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(rsc,new File("R-fname.png"));
		
		driver.findElement(By.id("lastName")).sendKeys("hira");
		TakesScreenshot tsc1 = (TakesScreenshot) driver;	
			File rsc1 = tsc1.getScreenshotAs(OutputType.FILE);
			FileHandler.copy(rsc1,new File("R-lname.png"));
	
	driver.findElement(By.id("username")).sendKeys("nilasihira");
	TakesScreenshot ts = (TakesScreenshot) driver;	
	File rs = ts.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(rs,new File("R-email.png"));
	
	driver.findElement(By.xpath("//*[@id=\"passwd\"]/div[1]/div/div[1]/input")).sendKeys("nila#123");
	TakesScreenshot r = (TakesScreenshot) driver;	
	File k = r.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(k,new File("R-password.png"));
	
	driver.findElement(By.xpath("//*[@id=\"confirm-passwd\"]/div[1]/div/div[1]/input")).sendKeys("nila#123");
	TakesScreenshot r1 = (TakesScreenshot) driver;	
	File k1 = r1.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(k1,new File("R-repassword.png"));
	
	Thread.sleep(30);
	driver.findElement(By.xpath("//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[3]/div[3]/div/div[1]/div/div/div[1]/div/input")).click();
	
	driver.findElement(By.xpath("//*[@id=\"accountDetailsNext\"]/div/button/span")).click();
	TakesScreenshot p = (TakesScreenshot) driver;	
	File f = p.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(f,new File("R-signup.png"));
}
@BeforeTest
public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Visalini S\\Downloads\\chromedriver.exe");
	  driver = new ChromeDriver();
}
	
	 @AfterTest
	  public void afterTest() {
		 System.out.println("After test is running");
	  }
}