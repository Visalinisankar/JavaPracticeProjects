package Login;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class NegativeLoginTest {
	String driverPath="C:\\Users\\Visalini S\\Downloads\\chromedriver.exe";
	public WebDriver driver;
  @Test
  public void f() throws IOException, InterruptedException {
  
  driver.manage().window().maximize();
	driver.get("https://auth.geeksforgeeks.org/?to=https://www.geeksforgeeks.org/");
	
	driver.findElement(By.id("luser")).sendKeys("visalinis@gmail.com");
	TakesScreenshot ts = (TakesScreenshot) driver;	
	File rs = ts.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(rs,new File("IL-email.png"));
	
	driver.findElement(By.id("password")).sendKeys("Viu@2001");
	TakesScreenshot r = (TakesScreenshot) driver;	
	File k = r.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(k,new File("IL-password.png"));
	Thread.sleep(30);
	driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/section[1]/form/button")).click();
	Thread.sleep(500);
	TakesScreenshot p = (TakesScreenshot) driver;	
	File f = p.getScreenshotAs(OutputType.FILE);
	FileHandler.copy(f,new File("IL-signin.png"));
	String actualUrl = "https://auth.geeksforgeeks.org/?to=https://www.geeksforgeeks.org/";
	String expectedUrl = driver.getCurrentUrl();
	Assert.assertEquals(expectedUrl, actualUrl);		
	
}
@BeforeTest
public void beforeTest() {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\Visalini S\\Downloads\\chromedriver.exe");
	  
	  driver = new ChromeDriver();
}
	 @AfterTest
	  public void afterTest() {
		 System.out.println("After test is running");
		 System.out.println("Invalid login");
	  }
	 }