package SearchAddtoCart;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class SearchAddtoCartTest {
	WebDriver driver;

	public void launchBrowser() throws IOException {

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Visalini S\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.ebay.com/");
		// Step-1 :: type cast driver object into takeScreenshot instance
		TakesScreenshot tsc = (TakesScreenshot) driver;
		// Step-2 :: Generate a screenshot as file
		File rsc = tsc.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(rsc, new File("ebaypage.png"));
	}

	public void searchProduct() throws InterruptedException, IOException {
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#gh-ac")).sendKeys("Women Watches");
		Thread.sleep(2000);
		// Step-1 :: type cast driver object into takeScreenshot instance
		TakesScreenshot tsc = (TakesScreenshot) driver;
		// Step-2 :: Generate a screenshot as file
		File rsc = tsc.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(rsc, new File("productname.png"));

		driver.findElement(By.id("gh-btn")).click();

		Thread.sleep(2000);
		TakesScreenshot t = (TakesScreenshot) driver;
		// Step-2 :: Generate a screenshot as file
		File r = t.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(r, new File("productpage.png"));
		driver.findElement(By.xpath("//*[@id=\"srp-river-results\"]/ul/li[1]/div/div[2]/a/div/span")).click();
		Thread.sleep(2000);
		TakesScreenshot ts = (TakesScreenshot) driver;
		// Step-2 :: Generate a screenshot as file
		File rs = ts.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(rs, new File("productdetail.png"));
		System.out.println("The title of the page is :" + driver.getTitle());

	}

	public void Addtocart() throws InterruptedException, IOException {

		driver.get("https://www.ebay.com/itm/362159434519?hash=item5452626b17:g:gu8AAOSwaQ1hG4RF&amdata=enc%3AAQAHAAAA4OPLikrXvJw4m48XMKjhgM2BFBvbBuTDm2FXPZcgJyH2FYto14Tx6r5lUrPJ8GZQWwDVWZrPXuxE83M6sCA8x3vIHrJpebKS9sfwcy9qfJoAuXwAb2h3OmYdvldCBCg0mgpZxbSR9PGUYJVG9NPZOV70o%2Bvg82kRWiX7ASa%2BCc8Ds5u%2BL%2BtVaupEdO2VgPsuiFKQI1i8ueCEfxlMEL%2Bnufs5%2F99YKEYdyXHdA90F9Zkh4yYfrXrx2gFyrUFjppZq7bwVF9OpB5NGl%2FnXHfoZROjmzy14TNx69u2yBwq2fP40%7Ctkp%3ABFBMzrG9r_Zg");
		driver.findElement(By.xpath("//*[@id=\"isCartBtn_btn\"]")).click();
		Thread.sleep(2000);
		TakesScreenshot tsc = (TakesScreenshot) driver;
		// Step-2 :: Generate a screenshot as file
		File rsc = tsc.getScreenshotAs(OutputType.FILE);
		FileHandler.copy(rsc, new File("addtocart.png"));

	}

	public void closeBrowser() {

		driver.quit();

	}

	@Test
	public void f() throws IOException {

		SearchAddtoCartTest obj = new SearchAddtoCartTest();
		try {
			obj.launchBrowser();

			obj.searchProduct();

			obj.Addtocart();

			obj.closeBrowser();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}